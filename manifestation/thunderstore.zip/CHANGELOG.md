1.0.0
- Created mod
- Added Teto, Defoko, LEON, and LOLA voices.

1.1.0
- Added vflower, GUMI, DEX, and DAINA voices.
# Fishingloid
 Vocal Synth voicebank pack for Webfishing AlternateVoices! To use, type the bolded name in the config for AlternateVoices. Be sure to type it exactly as written!
Currently has:
- **Teto**: Kasane Teto (Feminine Japanese + English UTAU voicebanks)
- **Defoko**: Utane Uta/Defoko (Feminine Japanese UTAU voicebank)
- **LOLA**: Vocaloid LOLA (Feminine English V1 VOCALOID voicebank)
- **LEON**: Vocaloid LEON (Masculine English V1 VOCALOID voicebank)
- **vflower**: Vocaloid flower (Androgynous Japanese V4 VOCALOID voicebank)
- **GUMI**: Vocaloid Megpoid (Feminine English V3 VOCALOID voicebank)
- **DEX**: Vocaloid DEX (Masculine English V4 VOCALOID voicebank)
- **DAINA**: Vocaloid DAINA (Feminine English V4 VOCALOID voicebank)
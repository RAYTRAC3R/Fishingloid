# Fishingloid
 Vocal Synth voicebank pack for Webfishing AlternateVoices! To use, type the bolded name in the config for AlternateVoices. Be sure to type it exactly as written!
Currently has:
- **Teto**: Kasane Teto (Feminine Japanese + English UTAU voicebanks)
- **Defoko**: Utane Uta/Defoko (Feminine Japanese UTAU voicebank)
- **LOLA**: Vocaloid LOLA (Feminine English V1 VOCALOID voicebank)
- **LEON**: Vocaloid LEON (Masculine English V1 VOCALOID voicebank)